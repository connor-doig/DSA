/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dsa;

/**
 *
 * @author C Doig
 */
public class Track {
    
    /**
     Defines our variables
     */
    
    private int trackId;
    private String trackTitle;
    private String artist;
    private String trackLength;
    private String composer;
    private String releaseDate;
    private String album;
    private String genre;
    protected Track next;
    
    public Track() {
    
}

  
    public Track(int trackID, String trackTitle, String artist, String trackLength, String composer, String releaseDate, String album, String genre){
        this.trackId = trackId;
        this.trackTitle = trackTitle;
        this.artist = artist;
        this.trackLength = trackLength;
        this.composer = composer;
        this.releaseDate = releaseDate;
        this.album = album;
        this.genre = genre;       
    }
    
    /**
     Sets up getters
     */
    
    public int getTrackId() {
        return trackId;
    }
       public String getArtist() {
        return artist;
    }
        public String getTrackTitle() {
        return trackTitle;
    }
        public String getTrackLength() {
        return trackLength;
    }
        public String getComposer() {
        return composer;
    }
        public String getReleaseDate() {
            return releaseDate;
        }
        public String getAlbum() {
        return album;
    }
        public String getGenre() {
        return genre;
        }
        
        /**
     Sets up the setters
     */
        
        public void setTrackId(int trackId) {
        this.trackId = trackId;
    }
        public void setArtist(String artist) {
        this.artist = artist;;
    }
        public void setTrackTitle(String trackTitle) {
        this.trackTitle = trackTitle;
    }
        public void setTrackLength(String trackLength) {
        this.trackLength = trackLength;
    }
        public void setComposer(String composer) {
        this.composer = composer;
    }
        public void setReleaseDate(String releaseDate) {
        this.releaseDate = releaseDate;
    }
        public void setAlbum(String album) {
        this.album = album;
    }
        public void setGenre(String genre) {
        this.genre = genre;
    }

        public void display(){
    
    }
   
    
    

    
    
}
