/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dsa;

/**
 * @author C Doig
 */
public interface InterfaceTracklist {
    
    /**
     
     */
    public void addTrack (int trackID, String trackTitle, String artist, int trackLength, String composer, String releaseDate, String album, String genre);
    public String displayTrack();
    public String searchTrackByTitle (String trackTitle);
    public String searchTrackByArtist (String artist);
    public String displayTrackByGenre (String genre);
    public String displayAllTrackInList ();
    

}