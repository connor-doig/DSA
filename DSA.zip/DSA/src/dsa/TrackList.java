/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dsa;

/**
 *
 * @author C Doig
 */
public class TrackList implements InterfaceTracklist {
    
    public Track firstTrack;
    
    TrackList() {
        firstTrack = null;
    }
    
    public boolean isEmpty() {
        return (firstTrack == null);
    }
    
    public void addTrack (int trackID, String trackTitle, String artist, String trackLength, String composer, String releaseDate, String album, String genre) {
        
        Track newTrack = new Track(trackID,trackTitle,artist,trackLength,composer,releaseDate, album,genre);
        
        newTrack.next = firstTrack;
        firstTrack = newTrack;
    }

    @Override
    public String displayTrack() {
        Track theTrack = firstTrack;
        String singleTrack ="";
        
        while (theTrack != null) {
            
            theTrack.display();
            
          singleTrack = ("Track= " + theTrack.getTrackId() + " title= " + theTrack.getTrackTitle() + " artist= " + theTrack.getArtist() + " TrackLength= " + theTrack.getTrackLength() + " composer= " + theTrack.getComposer()+ " Release Date= " + theTrack.getReleaseDate()+ " album= " + theTrack.getAlbum()+ " genre= " + theTrack.getGenre()    );
       theTrack = theTrack.next ;
       
        }
        return singleTrack;
    }
    
    @Override 
    public String searchTrackByTitle (String trackTitle){
        
        Track theTrack = firstTrack;
        
        if (!isEmpty()) {
            
            while (theTrack.getTrackTitle() !=trackTitle) {
            
                if (theTrack.next == null) {
                    return "No track found";
             
                }else {
                    theTrack = theTrack.next;
                }
        }
            
        } else {
            return "Empty List";
        }
    return theTrack.getTrackTitle();
    
    }
    
        @Override 
    public String searchTrackByArtist (String artist){
        
        Track theTrack = firstTrack;
        
        if (!isEmpty()) {
            
            while (theTrack.getArtist() !=artist) {
            
                if (theTrack.next == null) {
                    return "track not found";
             
                }else {
                    theTrack = theTrack.next;
                }
        }
            
        } else {
            return "list is empty";
        }
    return theTrack.getArtist();
    
    }

    @Override
    public void addTrack(int trackID, String trackTitle, String artist, int trackLength, String composer, String releaseDate, String album, String genre) {
    }

    /*
    never finished implementatrion due to deadline
    */
    @Override
    public String displayTrackByGenre(String genre) {
        return genre;
    }

    /*never finished */
    
    @Override
    public String displayAllTrackInList() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
