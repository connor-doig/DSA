/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dsa;

/**
 *
 * @author C Doig
 */
public class DSA {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        TrackList theTrackList = new TrackList();
        
        /* Adds Tracks */
        theTrackList.addTrack(1, "I Want It That Way", "Backstreet Boys", "3", "Kristian Lundin", "12/04/1999", "Millenium", "Pop");
        theTrackList.addTrack(2, "Shut Up", "Stormzy", "3", "XTC", "11/09/15", "Millenium", "Grime");
        theTrackList.addTrack(3, "Almost Famous", "Eminem", "5", "DJ Khalil", "18/06/10", "Recovery", "Rap");
        theTrackList.addTrack(4, "Shape Of You", "Ed Sheeran", "4", "Mac", "06/01/17", "Deluxe", "Pop");
        theTrackList.addTrack(5, "Firework", "Katy Perry", "4", "Stargate", "26/10/10", "Teenage Dream", "Pop");
        
        String foundTrack = theTrackList.searchTrackByTitle("Almost Famous");
        System.out.println("foundTrack\n" + foundTrack);
        System.out.println();
        
        String foundArtist = theTrackList.searchTrackByArtist("Stormzy");
        System.out.println("foundArtist\n" + foundArtist);
        System.out.println();
       
        /*
        Failed to implement by deadline
        
        String foundTracksByGenre = theTrackList.displayTrackByGenre("Pop");
        System.out.println("foundTracksByGenre\n" + foundTracksByGenre);
        System.out.println();
        
        String foundAllTrackData = theTrackList.displayAllTrackInList();
        System.out.println("foundAllTrackData\n" + foundAllTrackData);
        System.out.println();
        
        theTrackList.displayTrack();
        
        */
    }
    
}
